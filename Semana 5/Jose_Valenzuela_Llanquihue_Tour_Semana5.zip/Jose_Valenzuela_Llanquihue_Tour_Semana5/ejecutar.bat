@echo off
setlocal
cd /d "%~dp0"
java -jar dist\LlanquihueTourApp.jar %*
endlocal
