package cl.llanquihue.data;

import cl.llanquihue.model.Persona;
import cl.llanquihue.model.Guia;
import cl.llanquihue.model.Operador;
import cl.llanquihue.model.Proveedor;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class PersonaRepository {
    public List<Persona> cargar(Path archivo) throws IOException {
        List<Persona> personas = new ArrayList<>();
        for (String linea : Files.readAllLines(archivo)) {
            if (linea.isBlank() || linea.startsWith("#") || linea.startsWith("tipo;")) continue;
            personas.add(parsearLinea(linea));
        }
        return personas;
    }
    public Persona parsearLinea(String linea) {
        String[] c = linea.split(";", -1);
        if (c.length != 6) throw new IllegalArgumentException("Se esperaban 6 columnas separadas por punto y coma.");
        return switch (c[0].trim().toUpperCase()) {
            case "GUIA" -> new Guia(c[1], c[2], c[3], c[4], c[5]);
            case "OPERADOR" -> new Operador(c[1], c[2], c[3], c[4], c[5]);
            case "PROVEEDOR" -> new Proveedor(c[1], c[2], c[3], c[4], c[5]);
            default -> throw new IllegalArgumentException("Tipo desconocido: " + c[0]);
        };
    }
}
