package cl.llanquihue.model;

public class Operador extends Persona {
    private String servicio;
    public Operador(String rut, String nombre, String comuna, String telefono, String servicio) {
        super(rut, nombre, comuna, telefono, "OPERADOR"); setServicio(servicio);
    }
    public String getServicio() { return servicio; }
    public void setServicio(String servicio) { if (servicio == null || servicio.trim().isEmpty()) throw new IllegalArgumentException("El servicio es obligatorio."); this.servicio = servicio.trim(); }
    @Override public String toString() { return "Operador{" + datosComunes() + ", servicio=" + servicio + "}"; }
}
