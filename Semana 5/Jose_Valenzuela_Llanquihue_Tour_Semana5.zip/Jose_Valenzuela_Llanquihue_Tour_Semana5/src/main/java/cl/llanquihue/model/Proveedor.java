package cl.llanquihue.model;

public class Proveedor extends Persona {
    private String rubro;
    public Proveedor(String rut, String nombre, String comuna, String telefono, String rubro) {
        super(rut, nombre, comuna, telefono, "PROVEEDOR"); setRubro(rubro);
    }
    public String getRubro() { return rubro; }
    public void setRubro(String rubro) { if (rubro == null || rubro.trim().isEmpty()) throw new IllegalArgumentException("El rubro es obligatorio."); this.rubro = rubro.trim(); }
    @Override public String toString() { return "Proveedor{" + datosComunes() + ", rubro=" + rubro + "}"; }
}
