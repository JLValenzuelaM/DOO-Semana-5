package cl.llanquihue.service;

import cl.llanquihue.data.PersonaRepository;
import cl.llanquihue.model.Persona;
import java.io.IOException;
import java.nio.file.Path;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class PersonaService {
    private final PersonaRepository repository;
    private final List<Persona> personas = new ArrayList<>();
    public PersonaService(PersonaRepository repository) { this.repository = repository; }
    public int cargar(Path archivo) throws IOException {
        personas.clear(); Set<String> ruts = new HashSet<>(); int rechazados = 0; int fila = 0;
        for (String linea : java.nio.file.Files.readAllLines(archivo)) {
            fila++;
            if (linea.isBlank() || linea.startsWith("#") || linea.startsWith("tipo;")) continue;
            try {
                Persona p = repository.parsearLinea(linea);
                if (!ruts.add(normalizar(p.getRut()))) throw new IllegalArgumentException("RUT duplicado: " + p.getRut());
                personas.add(p);
            } catch (IllegalArgumentException e) { rechazados++; System.out.println("Fila " + fila + " omitida: " + e.getMessage()); }
        }
        return rechazados;
    }
    public List<Persona> listar() { return List.copyOf(personas); }
    public List<Persona> buscar(String consulta) {
        String q = normalizar(consulta);
        return personas.stream().filter(p -> normalizar(p.getNombre()).contains(q) || normalizar(p.getRut()).contains(q) || normalizar(p.getComuna()).contains(q)).toList();
    }
    public List<Persona> filtrarPorTipo(String tipo) { return personas.stream().filter(p -> p.getTipo().equalsIgnoreCase(tipo)).toList(); }
    private String normalizar(String s) { return Normalizer.normalize(s == null ? "" : s, Normalizer.Form.NFD).replaceAll("\\p{M}", "").toLowerCase(Locale.ROOT).trim(); }
}
