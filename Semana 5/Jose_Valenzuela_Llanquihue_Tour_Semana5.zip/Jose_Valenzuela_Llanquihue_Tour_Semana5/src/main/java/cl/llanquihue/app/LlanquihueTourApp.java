package cl.llanquihue.app;

import cl.llanquihue.data.PersonaRepository;
import cl.llanquihue.model.Persona;
import cl.llanquihue.service.PersonaService;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Scanner;

public class LlanquihueTourApp {
    public static void main(String[] args) {
        Path archivo = args.length > 0 ? Path.of(args[0]) : Path.of("data", "personas.csv");
        PersonaService servicio = new PersonaService(new PersonaRepository());
        try {
            if (!Files.exists(archivo)) throw new IllegalArgumentException("No se encontró el archivo: " + archivo.toAbsolutePath());
            int omitidos = servicio.cargar(archivo);
            System.out.println("\nLlanquihue Tour | Registros cargados: " + servicio.listar().size() + " | Omitidos: " + omitidos);
            menu(servicio);
        } catch (Exception e) {
            System.err.println("No fue posible iniciar la aplicación: " + e.getMessage());
            System.err.println("Verifica la ruta y el formato del archivo de datos.");
        }
    }
    private static void menu(PersonaService servicio) {
        try (Scanner sc = new Scanner(System.in)) {
            while (true) {
                System.out.println("\n1. Listar todos\n2. Buscar por nombre, RUT o comuna\n3. Filtrar por tipo\n0. Salir");
                System.out.print("Opción: "); String opcion = sc.nextLine().trim();
                switch (opcion) {
                    case "1" -> mostrar(servicio.listar());
                    case "2" -> { System.out.print("Texto a buscar: "); mostrar(servicio.buscar(sc.nextLine())); }
                    case "3" -> {
                        System.out.print("Tipo (GUIA, OPERADOR, PROVEEDOR): ");
                        String tipo = sc.nextLine().trim().toUpperCase();
                        if (!List.of("GUIA", "OPERADOR", "PROVEEDOR").contains(tipo)) System.out.println("Tipo no válido.");
                        else mostrar(servicio.filtrarPorTipo(tipo));
                    }
                    case "0" -> { System.out.println("Hasta pronto."); return; }
                    default -> System.out.println("Opción no válida. Ingresa 1, 2, 3 o 0.");
                }
            }
        }
    }
    private static void mostrar(List<Persona> personas) {
        if (personas.isEmpty()) { System.out.println("No se encontraron registros."); return; }
        personas.forEach(System.out::println);
        System.out.println("Total: " + personas.size());
    }
}
