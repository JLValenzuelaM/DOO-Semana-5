package cl.llanquihue.model;

public abstract class Persona {
    private final String rut;
    private String nombre;
    private String comuna;
    private String telefono;
    private final String tipo;

    protected Persona(String rut, String nombre, String comuna, String telefono, String tipo) {
        this.rut = requerido(rut, "RUT");
        this.nombre = requerido(nombre, "nombre");
        this.comuna = requerido(comuna, "comuna");
        this.telefono = requerido(telefono, "teléfono");
        this.tipo = requerido(tipo, "tipo");
    }
    private static String requerido(String valor, String campo) {
        if (valor == null || valor.trim().isEmpty()) throw new IllegalArgumentException("El campo " + campo + " es obligatorio.");
        return valor.trim();
    }
    public String getRut() { return rut; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = requerido(nombre, "nombre"); }
    public String getComuna() { return comuna; }
    public void setComuna(String comuna) { this.comuna = requerido(comuna, "comuna"); }
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = requerido(telefono, "teléfono"); }
    public String getTipo() { return tipo; }
    protected String datosComunes() { return "RUT=" + rut + ", nombre=" + nombre + ", comuna=" + comuna + ", teléfono=" + telefono; }
    @Override public String toString() { return tipo + "{" + datosComunes() + "}"; }
}
