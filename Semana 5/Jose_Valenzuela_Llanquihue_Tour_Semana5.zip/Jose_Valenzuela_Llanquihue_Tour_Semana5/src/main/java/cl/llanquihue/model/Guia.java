package cl.llanquihue.model;

public class Guia extends Persona {
    private String especialidad;
    public Guia(String rut, String nombre, String comuna, String telefono, String especialidad) {
        super(rut, nombre, comuna, telefono, "GUIA"); setEspecialidad(especialidad);
    }
    public String getEspecialidad() { return especialidad; }
    public void setEspecialidad(String especialidad) { if (especialidad == null || especialidad.trim().isEmpty()) throw new IllegalArgumentException("La especialidad es obligatoria."); this.especialidad = especialidad.trim(); }
    @Override public String toString() { return "Guía{" + datosComunes() + ", especialidad=" + especialidad + "}"; }
}
