# LlanquihueTourApp

## Descripción

Aplicación de consola para gestionar las personas y organizaciones vinculadas a la agencia turística Llanquihue Tour. Lee registros desde un archivo externo separado por punto y coma, crea objetos tipados en una colección dinámica `ArrayList`, evita RUT duplicados, informa filas inválidas y permite listar, buscar y filtrar registros.

## Paquetes y clases

- `cl.llanquihue.model`: `Persona` (clase abstracta), `Guia`, `Operador` y `Proveedor`. Los atributos son privados, con constructores, getters/setters, validaciones y representación `toString()`.
- `cl.llanquihue.data`: `PersonaRepository`, que interpreta las filas del archivo y crea el tipo de objeto correspondiente.
- `cl.llanquihue.service`: `PersonaService`, que administra la colección, carga registros, evita duplicados y realiza búsquedas y filtros.
- `cl.llanquihue.app`: `LlanquihueTourApp`, clase principal y menú de consola.
- `data/personas.csv`: datos de ejemplo externos. Encabezado y registros separados por `;`. El último campo contiene la especialidad, servicio o rubro según el tipo.

## Ejecutar desde IntelliJ IDEA

1. Abre la carpeta `LlanquihueTourApp` en IntelliJ IDEA.
2. Configura un JDK 17 o superior (File → Project Structure → Project SDK).
3. Abre `src/main/java/cl/llanquihue/app/LlanquihueTourApp.java` y selecciona **Run 'LlanquihueTourApp.main()'**.
4. Ejecuta con el directorio de trabajo en la carpeta raíz del proyecto para que encuentre `data/personas.csv`.

También puedes pasar la ruta de otro archivo como argumento del programa. El formato esperado es `TIPO;RUT;NOMBRE;COMUNA;TELEFONO;DETALLE`, donde `TIPO` puede ser `GUIA`, `OPERADOR` o `PROVEEDOR`.

## Distribución

El código no requiere dependencias externas. Para compilarlo desde PowerShell con un JDK instalado, ejecuta desde la raíz del proyecto:

```powershell
New-Item -ItemType Directory -Force out | Out-Null
javac -encoding UTF-8 -d out (Get-ChildItem -Recurse src/main/java -Filter *.java | ForEach-Object FullName)
jar --create --file dist/LlanquihueTourApp.jar --main-class cl.llanquihue.app.LlanquihueTourApp -C out .
java -jar dist/LlanquihueTourApp.jar
```

También puedes ejecutar `./compilar.ps1` en PowerShell para reconstruir el JAR o hacer doble clic en `ejecutar.bat` para iniciarlo. El archivo CSV se mantiene externo para facilitar su actualización. Ejecuta desde la carpeta raíz del proyecto; alternativamente entrega la ruta del CSV como argumento.
