$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$sourceFiles = Get-ChildItem -Path (Join-Path $projectRoot 'src\main\java') -Recurse -Filter '*.java' | ForEach-Object FullName
$classesPath = Join-Path $projectRoot 'out'
$jarPath = Join-Path $projectRoot 'dist\LlanquihueTourApp.jar'
New-Item -ItemType Directory -Force $classesPath, (Split-Path -Parent $jarPath) | Out-Null
javac -encoding UTF-8 -d $classesPath $sourceFiles
if ($LASTEXITCODE -ne 0) { throw 'La compilación falló.' }
jar --create --file $jarPath --main-class cl.llanquihue.app.LlanquihueTourApp -C $classesPath .
if ($LASTEXITCODE -ne 0) { throw 'No fue posible crear el archivo JAR.' }
Write-Host "Distribución creada: $jarPath"
